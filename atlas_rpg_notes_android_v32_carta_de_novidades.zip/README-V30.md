# Atlas RPG Notes v0.30 Beta — Avatar System v1

- Visual de corpo inteiro, pixel art procedimental offline em ângulo 3/4.
- Editor opcional pela Ficha; pode ser aberto e fechado sem modificar dados do personagem.
- Seleção inicial de quatro ou cinco opções em cada grupo, com Nenhum para itens opcionais.
- Avatar salvo dentro de `character.avatar`, preservado na exportação JSON e no backup do Atlas.
- Protótipo inicial **estático**, sem animação nem sprite sheets profissionais.
- Compatível com dados de versões anteriores; nenhuma ficha existente é migrada obrigatoriamente.
- Não inclui sincronização com o Mestre.
- Instalação por cima da v29 requer **a mesma chave JKS original**, mesmo applicationId e versionCode 30.

## Limites do teste
Os sprites são desenhados por código em Canvas e servem de prova de conceito visual e funcional. Para um lançamento final podemos substituir camadas por sprites PNG 128x128 artesanais/gerados, com posicionamento por raça. Algumas raças incomuns podem exigir bases próprias.
