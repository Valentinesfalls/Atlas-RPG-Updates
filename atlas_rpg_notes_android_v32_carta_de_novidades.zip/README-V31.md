# Atlas RPG Notes — v0.31.0 Beta

## Mudanças
- Retrato circular na ficha, focado no tórax e rosto, mantendo as personalizações salvas na v30.
- Expressões e poses dos braços (5 escolhas cada).
- Carta de novidades após a abertura animada do app, uma vez por atualização.
- Botão “📜 Ver novidades” na área de atualização, para reler a carta.
- A estrutura `AtlasAvatar.makeTokenDataUrl` permite gerar um token PNG circular do retrato no futuro grid tático (grid ainda não implementado).

## Observações
- O retrato continua sendo pixel art procedimental de protótipo, não uma arte final profissional.
- A detecção da primeira atualização com o sistema novo usa perfil salvo ou outros dados locais do Atlas como sinal de instalação anterior. Em novas instalações, a carta não abre automaticamente.
- Use a mesma chave de assinatura da v28–v30, `applicationId` inalterado e `versionCode 31`.
- Faça backup antes de atualizar e valide primeiro no seu celular. Não publique para todos antes de testar.
- Conteúdo das próximas cartas: `app/src/main/assets/www/release-notes.json`. O manifesto público `update-manifest.json` também deve refletir a nova versão.
