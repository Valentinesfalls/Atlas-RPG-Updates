/* Atlas RPG Notes v32 — histórico de novidades por versão, local e offline. */
(()=>{'use strict';
 const SEEN_KEY='atlasReleaseNotesLastSeenVersionCode'; // Compatível com v31.
 const PREVIOUS_KEY='atlasReleaseNotesPreviousVersionCode';
 const ARCHIVE='./release-notes.json';
 const host=document.createElement('div');host.id='atlasWhatsNew';host.hidden=true;
 host.innerHTML=`<section class="atlas-whats-new-card" role="dialog" aria-modal="true" aria-labelledby="atlasWhatsNewTitle" aria-describedby="atlasWhatsNewIntro">
  <div class="atlas-whats-new-ornament" aria-hidden="true">✦ ─ ✧ ─ ✦</div>
  <div class="atlas-whats-new-header"><div class="atlas-whats-new-seal"><img src="./icons/icon-192.png" alt="" /></div><div><div class="atlas-whats-new-eyebrow">ATLAS RPG NOTES · NOVA CENTAURIA</div><h2 id="atlasWhatsNewTitle">O que há de novo?</h2><p id="atlasWhatsNewIntro">Uma nova página foi escrita em seu grimório.</p></div></div>
  <div class="atlas-whats-new-transition" aria-label="Comparação de versões"><div class="atlas-whats-new-version"><small>Anterior</small><strong id="atlasPreviousVersion">—</strong></div><div class="atlas-whats-new-arrow" aria-hidden="true">➜</div><div class="atlas-whats-new-version current"><small>Atual</small><strong id="atlasCurrentVersion">—</strong></div></div>
  <p id="atlasWhatsNewNote" class="atlas-whats-new-note"></p>
  <div class="atlas-whats-new-protagonist" id="atlasWhatsNewProtagonist" hidden><span class="atlas-whats-new-avatar" id="atlasWhatsNewAvatar">✦</span><div><strong id="atlasWhatsNewCharacter">Seu aventureiro</strong><small>Seu retrato acompanha cada capítulo do Atlas.</small></div></div>
  <h3 class="atlas-whats-new-section-title" id="atlasWhatsNewSectionTitle">Novidades desta atualização</h3>
  <div class="atlas-whats-new-releases" id="atlasWhatsNewReleases"></div>
  <button class="atlas-whats-new-history-toggle" type="button" id="atlasWhatsNewHistory">📚 Ver histórico completo</button>
  <footer><button class="atlas-whats-new-ok" type="button" id="atlasWhatsNewClose">✦ Continuar aventura</button></footer>
 </section>`;
 document.body.appendChild(host);
 const el=(id)=>document.getElementById(id);
 const closeBtn=el('atlasWhatsNewClose'), historyBtn=el('atlasWhatsNewHistory');
 let archive=null, pending=false, shown=false, previousFocus=null, previousCode=null, historical=false;
 const escapeHTML=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
 const parseCode=value=>{if(value===null||value===''||!/^\d+$/.test(String(value)))return null;const code=Number(value);return Number.isSafeInteger(code)&&code>=0?code:null};
 const vlabel=code=>code===null?'Não identificada':(archive?.releases?.find(r=>r.versionCode===code)?.versionName||'v'+code);
 function hasOldInstallation(){
   try{const p=JSON.parse(localStorage.getItem('atlasAgentProfileV1')||'null');if(p?.initialized===true)return true}catch(_){}
   return !!(localStorage.getItem('camposAtlasSheetV1')||localStorage.getItem('camposAtlasExtraV1')||localStorage.getItem('camposAtlas'));
 }
 function saveCurrent(){
   try{
    if(!archive)return;
    const saved=parseCode(localStorage.getItem(SEEN_KEY));
    // Downgrades should never erase a future-version marker.
    if(saved!==null&&saved>archive.versionCode)return;
    if(saved===null||saved<archive.versionCode)localStorage.setItem(PREVIOUS_KEY,previousCode===null?'unknown':String(previousCode));
    localStorage.setItem(SEEN_KEY,String(archive.versionCode));
   }catch(_){/* Armazenamento indisponível; não bloqueie o aplicativo. */}
 }
 function close(){if(host.hidden)return;host.hidden=true;document.body.classList.remove('atlas-whats-new-open');saveCurrent();if(previousFocus?.isConnected)previousFocus.focus()}
 function renderChanges(){
   if(!archive)return;
   const available=archive.releases.filter(r=>r.versionCode<=archive.versionCode).sort((a,b)=>a.versionCode-b.versionCode);
   let selection=[];
   if(historical){selection=available;el('atlasWhatsNewSectionTitle').textContent='Crônicas de versões anteriores'}
   else if(previousCode!==null&&previousCode<archive.versionCode){selection=available.filter(r=>r.versionCode>previousCode);el('atlasWhatsNewSectionTitle').textContent=selection.length>1?'Novidades acumuladas':'Novidades desta atualização'}
   else{selection=available.filter(r=>r.versionCode===archive.versionCode);el('atlasWhatsNewSectionTitle').textContent='Novidades desta versão'}
   historyBtn.textContent=historical?'← Voltar às novidades':'📚 Ver histórico completo ('+available.length+' versões)';
   el('atlasWhatsNewReleases').innerHTML=selection.map(release=>`<article class="atlas-whats-new-release"><div class="atlas-whats-new-release-head"><strong>${escapeHTML(release.title)}</strong><small>v${release.versionCode}</small></div><ul class="atlas-whats-new-change-list">${release.changes.map(item=>`<li><span class="atlas-whats-new-bullet" aria-hidden="true">✧</span><span><span class="atlas-whats-new-type">${escapeHTML(item.type)}</span>${escapeHTML(item.text)}</span></li>`).join('')}</ul></article>`).join('');
 }
 function tryPortrait(){
   const box=el('atlasWhatsNewProtagonist');box.hidden=true;
   try{
     const character=window.AtlasAvatarBridge?.getCharacter?.();
     if(!character||!character.avatar?.enabled||!window.AtlasAvatar?.makeTokenDataUrl)return;
     const url=window.AtlasAvatar.makeTokenDataUrl(character.avatar);
     if(!url||!url.startsWith('data:image/png;base64,'))return;
     const image=document.createElement('img');image.src=url;image.alt='Retrato circular do personagem';
     const target=el('atlasWhatsNewAvatar');target.replaceChildren(image);
     el('atlasWhatsNewCharacter').textContent=String(character.name||'Seu aventureiro').slice(0,55);
     box.hidden=false;
   }catch(_){box.hidden=true}
 }
 function show(){
   if(!archive)return;
   pending=false;shown=true;historical=false;previousFocus=document.activeElement;
   const prevShown=previousCode===null?null:previousCode;
   el('atlasPreviousVersion').textContent=vlabel(prevShown);
   el('atlasCurrentVersion').textContent=archive.versionName;
   el('atlasWhatsNewNote').textContent=prevShown===null?'A versão anterior não foi registrada no dispositivo. Veja as novidades atuais ou consulte o histórico completo.':prevShown>=archive.versionCode?'Você está na versão mais recente registrada neste aparelho.':'Alterações entre a última versão registrada e a versão atual.';
   tryPortrait();renderChanges();host.hidden=false;document.body.classList.add('atlas-whats-new-open');const card=host.querySelector('.atlas-whats-new-card');card.scrollTop=0;el('atlasWhatsNewTitle').setAttribute('tabindex','-1');el('atlasWhatsNewTitle').focus({preventScroll:true});
 }
 function afterStartup(){
   if(!pending||shown)return;
   const splash=el('atlasSplash'),agent=el('atlasAgentScreen');
   if((splash&&!splash.hidden)||(agent&&!agent.hidden))return;
   show();
 }
 closeBtn.addEventListener('click',close);
 historyBtn.addEventListener('click',()=>{historical=!historical;renderChanges();historyBtn.focus()});
 host.addEventListener('click',e=>{if(e.target===host)close()});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!host.hidden){e.preventDefault();close()}});
 const watcher=new MutationObserver(afterStartup);
 for(const id of ['atlasSplash','atlasAgentScreen']){const target=el(id);if(target)watcher.observe(target,{attributes:true,attributeFilter:['hidden']})}
 const panel=document.querySelector('.atlas-pwa-actions');
 if(panel){const btn=document.createElement('button');btn.type='button';btn.id='atlasViewReleaseNotes';btn.textContent='📜 Ver novidades';btn.classList.add('secondary');btn.addEventListener('click',()=>{el('atlasPwaClose')?.click();if(archive)show()});panel.appendChild(btn)}
 async function init(){
   try{
     const response=await fetch(ARCHIVE,{cache:'no-store'});if(!response.ok)throw Error('Notas indisponíveis');
     const data=await response.json();
     if(!Number.isSafeInteger(data.versionCode)||!data.versionName||!Array.isArray(data.releases)||!data.releases.every(r=>Number.isSafeInteger(r.versionCode)&&Array.isArray(r.changes)&&r.changes.every(c=>typeof c.type==='string'&&typeof c.text==='string')))throw Error('Histórico inválido');
     archive=data;
     const stored=localStorage.getItem(SEEN_KEY);
     const seen=parseCode(stored);
     const isOld=stored===null?hasOldInstallation():(seen!==null&&seen<data.versionCode);
     previousCode=seen!==null&&seen<archive.versionCode?seen:null;
     // For re-opening the modal on the same version, preserve the prior transition.
     if(!isOld){
       const remembered=parseCode(localStorage.getItem(PREVIOUS_KEY));
       if(remembered!==null&&remembered<data.versionCode)previousCode=remembered;
       if(stored===null)saveCurrent();
       return;
     }
     pending=true;afterStartup();
   }catch(err){console.warn('[Atlas] Falha ao carregar novidades:',err)}
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
 window.AtlasReleaseNotes={open:()=>{if(archive)show()},getVersion:()=>archive?.versionName||null};
})();
