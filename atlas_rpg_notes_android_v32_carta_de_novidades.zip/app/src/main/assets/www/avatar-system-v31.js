/* Atlas RPG Notes — Ícone circular do personagem (v31). Sem rede, bibliotecas ou serviços externos. */
(()=>{'use strict';
const FIELDS={
 corpo:[{key:'body',label:'Biotipo',options:[['regular','Regular'],['forte','Robusto'],['esguio','Esguio'],['baixo','Compacto']]},{key:'skin',label:'Tom de pele',options:[['clara','Claro'],['media','Médio'],['escura','Escuro'],['cinza','Cinza fantástico'],['azul','Azul fantástico']]}],
 expressao:[{key:'expression',label:'Expressão',options:[['neutra','Neutra'],['seria','Séria'],['sorrindo','Sorrindo'],['furiosa','Furiosa'],['desconfiada','Desconfiada']]}],
 pose:[{key:'pose',label:'Posição dos braços',options:[['relaxados','Relaxados'],['cruzados','Braços cruzados'],['erguido','Mão erguida'],['conjurando','Conjurando'],['segurando','Segurando item']]}],
 cabelo:[{key:'hair',label:'Penteado',options:[['none','Nenhum'],['curto','Curto'],['medio','Médio'],['longo','Longo'],['preso','Preso']]},{key:'hairColor',label:'Cor do cabelo',options:[['preto','Preto'],['castanho','Castanho'],['ruivo','Ruivo'],['branco','Branco'],['azul','Azul arcano']]}],
 olhos:[{key:'eyes',label:'Olhar',options:[['sereno','Sereno'],['determinado','Determinado'],['sombrio','Sombrio'],['brilhante','Mágico']]},{key:'eyeColor',label:'Cor dos olhos',options:[['mel','Mel'],['verde','Verde'],['azul','Azul'],['vermelho','Vermelho'],['violeta','Violeta']]}],
 raca:[{key:'race',label:'Traço visual',options:[['none','Nenhum'],['elfo','Orelhas élficas'],['chifres','Chifres'],['presas','Presas'],['runa','Marcas rúnicas']]}],
 roupa:[{key:'outfit',label:'Vestuário',options:[['aventureiro','Aventureiro'],['guerreiro','Guerreiro'],['mago','Mago'],['cacador','Caçador'],['nobre','Nobre sombrio']]}],
 capa:[{key:'cloak',label:'Manto e capa',options:[['none','Nenhum'],['curta','Capa curta'],['longa','Capa longa'],['rasgada','Capa rasgada'],['capuz','Com capuz']]}],
 acessorio:[{key:'accessory',label:'Acessório',options:[['none','Nenhum'],['brinco','Brinco'],['amuleto','Amuleto'],['bolsa','Bolsa'],['frasco','Frasco']]}],
 arma:[{key:'weapon',label:'Equipamento visível',options:[['none','Nenhum'],['espada','Espada'],['adaga','Adaga'],['cajado','Cajado'],['arco','Arco']]}],
 magia:[{key:'magic',label:'Efeito mágico',options:[['none','Nenhum'],['arcano','Azul arcano'],['sombrio','Sombras'],['natural','Essência natural'],['divino','Brilho divino']]}]
};
const TITLES={corpo:'Corpo',expressao:'Expressão',pose:'Braços',cabelo:'Cabelo',olhos:'Olhos',raca:'Raça',roupa:'Roupa',capa:'Capa',acessorio:'Acessório',arma:'Arma',magia:'Magia'};
const COLORS={skin:{clara:'#e7b48c',media:'#b77c5d',escura:'#754631',cinza:'#929397',azul:'#7796b6'},hairColor:{preto:'#25242b',castanho:'#624033',ruivo:'#aa583b',branco:'#c5c8c7',azul:'#4068a3'},eyeColor:{mel:'#bc8457',verde:'#78a47b',azul:'#76acd2',vermelho:'#d96a62',violeta:'#ab83c6'}};
const DEFAULT={expression:'neutra',pose:'relaxados',body:'regular',skin:'media',hair:'medio',hairColor:'preto',eyes:'determinado',eyeColor:'mel',race:'none',outfit:'aventureiro',cloak:'none',accessory:'none',weapon:'none',magic:'none'};
let draft={...DEFAULT},category='corpo',modal=null;
function safe(input){let obj=input&&typeof input==='object'?input:{};let out={};Object.values(FIELDS).flat().forEach(def=>{out[def.key]=def.options.some(o=>o[0]===obj[def.key])?obj[def.key]:DEFAULT[def.key]});return out}
const shallow={};function shade(hex,delta){const c=hex.replace('#','');return '#'+[0,2,4].map(i=>Math.max(0,Math.min(255,parseInt(c.slice(i,i+2),16)+delta)).toString(16).padStart(2,'0')).join('')}
function draw(canvas,a){if(!canvas)return;const d=safe(a),ctx=canvas.getContext('2d');canvas.width=96;canvas.height=128;ctx.clearRect(0,0,96,128);ctx.imageSmoothingEnabled=false;
 const skin=COLORS.skin[d.skin],hair=COLORS.hairColor[d.hairColor],iris=COLORS.eyeColor[d.eyeColor];
 const palette={aventureiro:['#444a52','#7b5741','#bc9a69'],guerreiro:['#647381','#394b57','#d1b786'],mago:['#383c70','#465b96','#b8a6cc'],cacador:['#485b49','#6b5941','#bca56e'],nobre:['#633545','#3d334c','#d9b472']};const [cloth,trim,metal]=palette[d.outfit];
 const rect=(x,y,w,h,col)=>{ctx.fillStyle=col;ctx.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h))};
 const poly=(pts,col)=>{ctx.fillStyle=col;ctx.beginPath();ctx.moveTo(...pts[0]);for(let i=1;i<pts.length;i++)ctx.lineTo(...pts[i]);ctx.closePath();ctx.fill()};
 const block=(x,y,w,h,col,outline='#24222a')=>{rect(x-2,y-2,w+4,h+4,outline);rect(x,y,w,h,col)};
 // Sombra projetada — o corpo mantém uma perspectiva de 3/4 voltada à direita.
 rect(20,120,59,3,'#13151b77');rect(26,123,47,2,'#11131755');
 const tall=d.body==='forte'?5:d.body==='esguio'?-2:0;const small=d.body==='baixo'?5:0;
 const shoulders=d.body==='forte'?31:d.body==='esguio'?22:26;const torsoY=62+small;const sx=49-shoulders/2;
 // Manto atrás do corpo.
 if(d.cloak!=='none'){
  const end=d.cloak==='curta'?90:d.cloak==='longa'?119:115;
  poly([[sx-9,torsoY-2],[79,torsoY-7],[84,83],[89,end],[74,end+1],[68,92],[32,end],[18,end-1],[24,82]],'#26212b');
  poly([[sx-5,torsoY+1],[76,torsoY-3],[79,83],[83,end-5],[68,end-1],[62,90],[32,end-4],[23,end-3],[28,84]],'#5e3045');
  if(d.cloak==='rasgada'){poly([[19,end-6],[28,end-14],[34,end],[22,end]],'#1c2331');rect(78,end-13,5,7,'#1c2331')}
  rect(31,torsoY+6,2,28,'#ac6d70');
 }
 // Pernas, botas e panturrilhas.
 poly([[37,91+small],[52,91+small],[52,113],[47,119],[34,117]],'#202831');
 poly([[55,90+small],[70,91+small],[75,115],[64,118],[53,111]],'#252a31');
 block(32,111,17,8,'#4c3c37');rect(33,114,14,2,'#846b50');rect(29,119,22,5,'#1f232a');rect(32,121,19,3,'#5e5148');
 block(62,111,17,8,'#443736');rect(64,114,13,2,'#88745b');rect(61,119,23,5,'#1c2028');rect(63,122,21,2,'#6b5a49');
 // Braço mais distante do observador.
 if(d.pose==='relaxados'){
 poly([[67,68+small],[79,73+small],[84,92+small],[76,101+small],[66,89+small]],'#20212a');
 poly([[70,73+small],[78,76+small],[81,91+small],[75,95+small]],shade(cloth,-5));
 }
 // Torso em perspectiva; ombro da direita mais abaixo.
 poly([[sx-4,torsoY],[sx+shoulders+9,torsoY+5],[sx+shoulders+7,100],[sx-7,97]],'#1e222b');
 poly([[sx-1,torsoY+3],[sx+shoulders+5,torsoY+7],[sx+shoulders+3,96],[sx-3,93]],cloth);
 poly([[sx+shoulders-3,torsoY+6],[sx+shoulders+5,torsoY+7],[sx+shoulders+3,95],[sx+shoulders-4,95]],shade(cloth,-19));
 rect(sx+4,torsoY+8,3,24,shade(cloth,30));rect(sx+10,torsoY+7,2,29,shade(cloth,-20));
 // Sobreposição de classe.
 if(d.outfit==='guerreiro'){poly([[sx-3,torsoY+6],[sx+shoulders+5,torsoY+7],[sx+shoulders,torsoY+22],[sx+7,torsoY+26]],'#8697a0');rect(sx+8,torsoY+14,19,3,'#c2ccd0');rect(sx+14,torsoY+8,3,19,'#556372')}
 if(d.outfit==='mago'){poly([[sx+5,torsoY+12],[sx+shoulders-3,torsoY+14],[sx+shoulders-7,109],[sx+4,105]],'#34315d');rect(sx+11,torsoY+22,12,2,'#9a83b8');rect(sx+15,torsoY+29,4,4,'#8da3dc')}
 if(d.outfit==='nobre'){poly([[sx+5,torsoY+10],[sx+shoulders-2,torsoY+11],[sx+shoulders,107],[sx+2,104]],'#4b263f');rect(sx+9,torsoY+12,2,28,'#b39b6f')}
 if(d.outfit==='cacador'){rect(sx+9,torsoY+6,6,29,'#786243');rect(sx+4,torsoY+24,35,4,'#37332b')}
 // Peitoral correias e cinto com ferragens.
 poly([[sx+3,torsoY+8],[sx+9,torsoY+7],[sx+30,torsoY+30],[sx+25,torsoY+32]],trim);
 rect(sx-2,torsoY+29,shoulders+9,5,'#342d2a');rect(sx+14,torsoY+28,7,7,metal);rect(sx+16,torsoY+30,3,3,'#292c32');
 for(let i=0;i<5;i++)rect(sx+2+(i*6),torsoY+34,2,1,shade(metal,-25));
 // Braço mais próximo com luva.
 if(d.pose==='relaxados'){
 poly([[sx-8,torsoY+7],[sx,torsoY+6],[sx-4,torsoY+30],[sx-11,torsoY+36],[sx-16,torsoY+32]],'#191e27');
 poly([[sx-7,torsoY+9],[sx-1,torsoY+8],[sx-5,torsoY+27],[sx-13,torsoY+30]],shade(cloth,10));
 rect(sx-13,torsoY+29,12,5,'#655145');rect(sx-15,torsoY+32,11,9,'#342d2d');rect(sx-14,torsoY+34,4,3,'#ad875d');
 }
 // Poses do busto, desenhadas sobre o peitoral e sob o rosto.
 if(d.pose==='cruzados'){
   poly([[28,78],[36,76],[60,87],[74,82],[79,87],[72,95],[48,94],[27,86]],'#24242e');
   poly([[30,79],[39,80],[61,88],[70,84],[74,87],[69,91],[47,92],[28,84]],shade(cloth,11));
   rect(59,85,10,7,shade(skin,-7));rect(33,86,10,7,shade(skin,-8));
   rect(31,84,7,3,metal);rect(67,83,6,3,metal);
 } else if(d.pose==='erguido'){
   poly([[24,80],[31,75],[34,69],[24,55],[18,56],[19,71]],shade(cloth,9));
   block(17,47,10,13,shade(skin,-10));rect(19,45,3,6,skin);
   poly([[74,74],[82,77],[79,100],[71,104],[66,98]],shade(cloth,-8));
 } else if(d.pose==='conjurando'){
   poly([[25,76],[35,77],[26,65],[16,62],[13,68],[20,78]],shade(cloth,12));
   block(9,54,12,11,skin);rect(11,52,3,6,shade(skin,12));
   poly([[74,75],[83,78],[84,89],[79,95],[70,85]],shade(cloth,-4));
   rect(7,46,4,7,'#8cb9f9');rect(21,43,3,5,'#a0d6f8');rect(2,62,4,4,'#6199d9');
 } else if(d.pose==='segurando'){
   poly([[26,75],[35,77],[46,85],[43,93],[27,91],[21,83]],shade(cloth,8));
   rect(41,84,9,9,shade(skin,-6));
   poly([[70,73],[79,79],[78,96],[71,99],[65,88]],shade(cloth,-6));
 }
 // Pescoço.
 rect(48,54+small,13,13,'#242027');rect(49,54+small,11,11,shade(skin,-22));rect(50,57+small,5,5,shade(skin,5));
 // Orelha racial (atrás da cabeça).
 if(d.race==='elfo'){poly([[25,44+small],[16,29+small],[21,52+small],[28,56+small]],'#25232c');poly([[25,46+small],[19,35+small],[22,50+small]],skin)}
 // Face volumétrica em 3/4 (nariz projetado à direita).
 poly([[33,21+small],[64,18+small],[72,27+small],[73,47+small],[68,56+small],[55,62+small],[37,58+small],[29,49+small],[29,32+small]],'#22232a');
 poly([[36,23+small],[62,22+small],[69,29+small],[70,45+small],[65,53+small],[54,59+small],[39,55+small],[32,46+small],[32,33+small]],skin);
 poly([[58,23+small],[66,26+small],[69,42+small],[65,52+small],[56,58+small],[55,55+small]],shade(skin,-15));
 rect(33,32+small,3,17,shade(skin,12));rect(64,42+small,8,4,shade(skin,8));rect(69,45+small,3,2,shade(skin,-27));
 rect(48,52+small,10,2,shade(skin,-35));rect(54,55+small,5,1,shade(skin,12));
 // Olhos com perspectiva, olho mais próximo maior.
 const eyeY=40+small;rect(39,eyeY,9,2,'#24222b');rect(57,eyeY-1,8,2,'#24222b');rect(41,eyeY+2,6,5,'#eee4d9');rect(58,eyeY+1,5,5,'#eee4d9');
 rect(44,eyeY+2,3,5,iris);rect(60,eyeY+1,3,5,iris);rect(46,eyeY+3,1,2,'#21242e');rect(62,eyeY+2,1,2,'#21242e');
 if(d.eyes==='sombrio'){rect(39,eyeY,9,3,'#27212a');rect(57,eyeY-1,9,3,'#27212a')}
 if(d.eyes==='sereno'){rect(39,eyeY,10,1,'#29232a');rect(56,eyeY-1,8,1,'#29232a')}
 if(d.eyes==='brilhante'){rect(45,eyeY+1,1,2,'#efffff');rect(61,eyeY,1,2,'#efffff')}
 // Expressões do retrato — boca e sobrancelhas adaptadas à pose.
 if(d.expression==='sorrindo'){
   rect(49,52+small,13,2,shade(skin,-62));rect(52,54+small,8,2,'#f3d7c5');
 } else if(d.expression==='furiosa'){
   rect(38,39+small,12,3,'#24202b');rect(57,36+small,10,3,'#24202b');
   rect(49,54+small,13,3,shade(skin,-69));
 } else if(d.expression==='desconfiada'){
   rect(39,38+small,10,2,'#29232a');rect(59,36+small,8,2,'#29232a');
   rect(51,54+small,7,2,shade(skin,-54));
 } else if(d.expression==='seria'){
   rect(41,38+small,8,2,'#2e2830');rect(57,38+small,10,2,'#2e2830');
   rect(49,54+small,12,2,shade(skin,-54));
 }
 // Traços faciais.
 if(d.race==='presas'){rect(56,54+small,2,4,'#ebe5cf');rect(62,53+small,2,4,'#ebe5cf')}
 if(d.race==='runa'){rect(35,46+small,2,9,'#6bc3e7');rect(37,49+small,4,2,'#9ddaea');rect(61,29+small,2,4,'#63b4d7')}
 // Penteados sempre sobre os detalhes de rosto.
 if(d.hair!=='none'){
  poly([[30,31+small],[30,21+small],[38,15+small],[56,11+small],[67,15+small],[73,22+small],[71,33+small],[64,31+small],[58,24+small],[46,29+small],[38,31+small]],'#1c202a');
  poly([[32,30+small],[33,22+small],[41,17+small],[56,14+small],[66,17+small],[70,23+small],[66,29+small],[59,22+small],[47,27+small],[40,30+small]],hair);
  rect(37,20+small,7,3,shade(hair,26));rect(51,16+small,10,2,shade(hair,22));
  if(d.hair==='medio'||d.hair==='longo'){poly([[31,28+small],[36,31+small],[37,58+small],[33,62+small],[27,54+small],[28,36+small]],'#201d29');poly([[31,30+small],[34,32+small],[35,54+small],[30,50+small]],hair)}
  if(d.hair==='longo'){poly([[65,29+small],[75,31+small],[76,78+small],[67,79+small],[62,56+small]],'#22202a');poly([[67,32+small],[72,34+small],[73,74+small],[67,70+small]],hair)}
  if(d.hair==='preso'){rect(26,25+small,10,29,'#20212a');rect(28,28+small,6,22,hair);poly([[23,34+small],[28,34+small],[29,68+small],[22,71+small]],hair)}
  rect(54,18+small,3,7,shade(hair,17));rect(42,23+small,3,5,shade(hair,-22));
 }
 if(d.cloak==='capuz') {poly([[27,25+small],[35,13+small],[55,9+small],[72,15+small],[77,32+small],[69,23+small],[64,16+small],[36,23+small],[31,42+small]],'#29242d');rect(30,29+small,4,24,'#6b394c');rect(70,27+small,4,23,'#6b394c')}
 if(d.race==='chifres'){poly([[38,19+small],[28,3+small],[32,20+small],[44,24+small]],'#211d25');poly([[56,14+small],[67,2+small],[70,20+small],[65,22+small]],'#231d26');rect(34,14+small,4,4,'#9c8270');rect(64,13+small,4,4,'#947867')}
 // Adornos e acessórios.
 if(d.accessory==='brinco'){rect(29,50+small,3,7,'#cdb47b');rect(28,56+small,5,3,'#9fb9ce')}
 if(d.accessory==='amuleto'){rect(53,71+small,3,8,'#d8bd83');rect(51,79+small,7,7,'#3d95bb');rect(53,80+small,3,4,'#b8e9f2')}
 if(d.accessory==='bolsa'){rect(71,91+small,16,16,'#1e222b');rect(73,93+small,13,12,'#72513d');rect(78,95+small,3,2,'#cdac7b')}
 if(d.accessory==='frasco'){rect(72,97+small,7,13,'#222631');rect(73,100+small,5,8,'#568eb2');rect(75,97+small,2,3,'#a6a6a7')}
 // Armas visíveis, seguradas na mão próxima.
 if(d.weapon==='espada'){rect(14,58+small,3,58,'#20242c');rect(15,60+small,1,42,'#aebfc9');rect(12,104+small,13,4,'#ccac74');rect(16,107+small,3,16,'#69513d');rect(15,120+small,5,3,'#cfaa76');poly([[14,59+small],[18,59+small],[16,51+small]],'#c0cbd0')}
 if(d.weapon==='adaga'){rect(18,79+small,3,26,'#aab3ba');rect(15,101+small,10,4,'#d0aa68');rect(18,105+small,4,13,'#6d4b3b')}
 if(d.weapon==='cajado'){rect(13,31+small,5,91,'#60402f');rect(14,32+small,2,89,'#a87c51');rect(10,21+small,12,14,'#27313f');rect(12,24+small,8,8,'#6593ce');rect(13,25+small,3,4,'#cde7fa')}
 if(d.weapon==='arco'){poly([[13,43+small],[8,54+small],[4,70+small],[6,91+small],[13,107+small],[15,105+small],[10,85+small],[9,68+small],[14,48+small]],'#765a3e');rect(14,46+small,1,59,'#bfc4bd')}
 // Magias suaves, sem efeitos sobre a ficha nem status de combate.
 if(d.magic!=='none'){const glows={arcano:'#77b8fa',sombrio:'#9863b5',natural:'#83bf6f',divino:'#f4d48e'};const glow=glows[d.magic];[[8,27,3,6],[84,45,4,5],[5,100,4,4],[79,18,3,7],[31,8,2,4]].forEach(([x,y,w,h],i)=>rect(x+(i%2)*2,y,w,h,glow));rect(8,29,10,1,shade(glow,-24));rect(82,49,9,1,shade(glow,-28));}
 // Dithering / brilho metalizado pontual.
 for(let i=0;i<6;i++){rect(sx+8+i*4,torsoY+10+(i%3)*4,1,1,shade(metal,-14))}
}
// Mesmo desenho persistido na ficha; apenas a apresentação muda para busto circular.
function drawPortrait(canvas,a){
 if(!canvas)return;
 const source=document.createElement('canvas');draw(source,a);
 const size=128;canvas.width=size;canvas.height=size;
 const ctx=canvas.getContext('2d');ctx.clearRect(0,0,size,size);
 ctx.save();ctx.beginPath();ctx.arc(64,64,61,0,Math.PI*2);ctx.clip();
 const gradient=ctx.createRadialGradient(61,44,6,64,66,87);
 gradient.addColorStop(0,'#455466');gradient.addColorStop(0.58,'#263344');gradient.addColorStop(1,'#111820');
 ctx.fillStyle=gradient;ctx.fillRect(0,0,size,size);
 ctx.globalAlpha=.18;ctx.strokeStyle='#b7cfed';ctx.lineWidth=1;
 ctx.beginPath();ctx.arc(65,80,43,0,Math.PI*2);ctx.stroke();
 ctx.globalAlpha=1;ctx.imageSmoothingEnabled=false;
 // Região entre cabeça e parte superior do tórax, sem botas e pernas.
 ctx.drawImage(source,8,1,80,81,0,0,size,size);
 ctx.restore();ctx.strokeStyle='#c6a36e';ctx.lineWidth=4;
 ctx.beginPath();ctx.arc(64,64,61,0,Math.PI*2);ctx.stroke();
 ctx.strokeStyle='#6c84a4';ctx.lineWidth=1;ctx.beginPath();ctx.arc(64,64,57,0,Math.PI*2);ctx.stroke();
}
function bridge(){return window.AtlasAvatarBridge}
function avatarData(){const c=bridge()?.getCharacter();return c&&c.avatar?.enabled?safe(c.avatar):null}
function renderEntry(){const root=document.getElementById('atlasAvatarEntry');if(!root)return;const avatar=avatarData();root.innerHTML=`<div class="atlas-avatar-thumb" id="atlasAvatarThumb">${avatar?'<canvas width="128" height="128" aria-label="Retrato circular do personagem, do tórax para cima"></canvas>':'<div class="avatar-empty" aria-hidden="true">✦</div>'}</div><div class="atlas-avatar-copy"><strong>${avatar?'Retrato do seu personagem':'Retrato opcional'}</strong><p>${avatar?'Ícone circular do tórax para cima, pronto para um futuro token de combate. Pode editar a qualquer momento.':'Crie um retrato circular em pixel art sombrio ou continue sem avatar. Você pode criar depois.'}</p><button id="atlasAvatarOpen" type="button">${avatar?'✎ Editar retrato':'✦ Criar retrato'}</button></div>`;
 if(avatar)drawPortrait(root.querySelector('canvas'),avatar);root.querySelector('#atlasAvatarOpen').onclick=openEditor;
}
function htmlEscape(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function renderControls(){const box=document.getElementById('atlasAvatarControls');if(!box)return;const fields=FIELDS[category];box.innerHTML=`<div class="atlas-avatar-categories" role="tablist" aria-label="Categorias de aparência">${Object.keys(FIELDS).map(key=>`<button type="button" role="tab" aria-selected="${key===category}" data-avatar-category="${key}">${TITLES[key]}</button>`).join('')}</div>${fields.map(field=>`<div class="atlas-avatar-field"><label>${field.label}</label><div class="atlas-avatar-options">${field.options.map(([value,label])=>`<button type="button" aria-pressed="${draft[field.key]===value}" data-avatar-key="${field.key}" data-avatar-value="${value}">${COLORS[field.key]?.[value]?`<span class="atlas-avatar-dot" style="background:${COLORS[field.key][value]}"></span>`:''}${htmlEscape(label)}</button>`).join('')}</div></div>`).join('')}<p class="atlas-avatar-status">Busto em 3/4 · recorte circular · pronto para futuro token tático</p>`;
 box.querySelectorAll('[data-avatar-category]').forEach(b=>b.onclick=()=>{category=b.dataset.avatarCategory;renderControls()});box.querySelectorAll('[data-avatar-key]').forEach(b=>b.onclick=()=>{draft[b.dataset.avatarKey]=b.dataset.avatarValue;drawPortrait(document.getElementById('atlasAvatarCanvas'),draft);renderControls()});
 const active=box.querySelector('[data-avatar-category][aria-selected="true"]');if(active)active.scrollIntoView({block:'nearest',inline:'center'});
}
function openEditor(){if(!modal)makeModal();draft={...DEFAULT,...(avatarData()||{})};category='corpo';modal.hidden=false;document.body.style.overflow='hidden';document.getElementById('atlasAvatarRemove').hidden=!avatarData();renderControls();drawPortrait(document.getElementById('atlasAvatarCanvas'),draft);document.getElementById('atlasAvatarClose').focus()}
function closeEditor(){if(modal)modal.hidden=true;document.body.style.overflow=''}
function makeModal(){modal=document.createElement('div');modal.id='atlasAvatarModal';modal.setAttribute('role','dialog');modal.setAttribute('aria-modal','true');modal.setAttribute('aria-label','Ateliê de personagens');modal.hidden=true;modal.innerHTML=`<div class="atlas-avatar-dialog"><header class="atlas-avatar-top"><div><h2>✦ Ateliê de Personagens</h2><p>Avatar System v1 · Nova Centauria · totalmente opcional</p></div><button class="atlas-avatar-close" id="atlasAvatarClose" aria-label="Fechar editor" type="button">×</button></header><div class="atlas-avatar-body"><div class="atlas-avatar-stage"><canvas id="atlasAvatarCanvas" width="96" height="128" aria-label="Prévia do avatar de corpo inteiro em pixel art"></canvas><small>Pixel art sombrio · busto · ícone circular · 3/4</small></div><div class="atlas-avatar-controls" id="atlasAvatarControls"></div></div><footer class="atlas-avatar-bottom"><button type="button" id="atlasAvatarRandom">🎲 Aleatório</button><button type="button" id="atlasAvatarClear">↺ Limpar</button><button type="button" class="avatar-remove" id="atlasAvatarRemove">Remover avatar</button><button type="button" class="avatar-skip" id="atlasAvatarSkip">Pular</button><button type="button" class="avatar-save" id="atlasAvatarSave">✓ Salvar avatar</button></footer></div>`;document.body.appendChild(modal);
 document.getElementById('atlasAvatarClose').onclick=closeEditor;
 document.getElementById('atlasAvatarSkip').onclick=closeEditor;
 document.getElementById('atlasAvatarRemove').onclick=()=>{if(!avatarData()){closeEditor();return}if(!confirm('Remover o avatar desta ficha? O personagem e seus outros dados serão preservados.'))return;bridge()?.saveAvatar(null);closeEditor();renderEntry()};
 document.getElementById('atlasAvatarClear').onclick=()=>{draft={...DEFAULT};drawPortrait(document.getElementById('atlasAvatarCanvas'),draft);renderControls()};
 document.getElementById('atlasAvatarRandom').onclick=()=>{for(const f of Object.values(FIELDS).flat()){const options=f.options;draft[f.key]=options[Math.floor(Math.random()*options.length)][0]}drawPortrait(document.getElementById('atlasAvatarCanvas'),draft);renderControls()};
 document.getElementById('atlasAvatarSave').onclick=()=>{if(!bridge()){alert('A ficha ainda não está disponível. Abra a aba Ficha e tente novamente.');return}bridge().saveAvatar({enabled:true,...safe(draft)});closeEditor();renderEntry()};
 modal.addEventListener('click',e=>{if(e.target===modal)closeEditor()});document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!modal.hidden)closeEditor()});
}
function init(){const summary=document.getElementById('sheetSummary');if(!summary)return;const div=document.createElement('div');div.id='atlasAvatarEntry';summary.insertAdjacentElement('afterend',div);renderEntry();
 // Atualiza o cartão caso a ficha seja importada, recriada ou editada.
 const observer=new MutationObserver(()=>{if(!modal||modal.hidden)renderEntry()});observer.observe(summary,{childList:true,subtree:false});
 window.addEventListener('atlas:avatar-saved',renderEntry);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
window.AtlasAvatar={openEditor,renderEntry,draw,drawPortrait,makeTokenDataUrl:(avatar)=>{const token=document.createElement('canvas');drawPortrait(token,avatar);return token.toDataURL('image/png')}};
})();
