package com.novacentauria.atlas;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.HashMap;

public class MainActivity extends Activity {
    private static final String APP_ORIGIN = "https://appassets.androidplatform.net";
    private static final String APP_PREFIX = APP_ORIGIN + "/assets/";
    private static final int PICK_IMPORT = 101;
    private static final int PICK_EXPORT = 102;
    private WebView web;
    private ValueCallback<Uri[]> pendingUpload;
    private byte[] pendingExport;
    private String pendingExportMime;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(23,18,14));
        getWindow().setNavigationBarColor(Color.rgb(23,18,14));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(23,18,14));
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (Build.VERSION.SDK_INT >= 26) settings.setSafeBrowsingEnabled(true);
        // A mesma origem HTTPS é preservada em todas as versões APK: armazenamento persistente.
        web.addJavascriptInterface(new AtlasNativeBridge(), "AtlasNative");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return serveBundledAsset(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (isInternal(url)) return false;
                if ("https".equals(url.getScheme()) || "http".equals(url.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, url)); } catch (Exception ignored) { }
                }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pendingUpload != null) pendingUpload.onReceiveValue(null);
                pendingUpload = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "application/pdf", "text/plain"});
                try { startActivityForResult(intent, PICK_IMPORT); }
                catch (ActivityNotFoundException ex) { pendingUpload.onReceiveValue(null); pendingUpload=null; return false; }
                return true;
            }
        });
        web.loadUrl(APP_PREFIX + "index.html");
    }

    private boolean isInternal(Uri uri) {
        return uri != null && "https".equals(uri.getScheme())
                && "appassets.androidplatform.net".equals(uri.getHost())
                && uri.getPath() != null && uri.getPath().startsWith("/assets/");
    }

    private WebResourceResponse serveBundledAsset(Uri uri) {
        if (!isInternal(uri)) return null;
        String rawPath = uri.getPath().substring("/assets/".length());
        if (rawPath.isEmpty()) rawPath = "index.html";
        // Impede acesso a arquivos fora da pasta www.
        if (rawPath.contains("..") || rawPath.startsWith("/") || rawPath.contains("\\")) return missing();
        try {
            InputStream input = getAssets().open("www/" + rawPath);
            String mime="application/octet-stream";
            if(rawPath.endsWith(".html")) mime="text/html";
            else if(rawPath.endsWith(".js")) mime="text/javascript";
            else if(rawPath.endsWith(".json") || rawPath.endsWith(".webmanifest")) mime="application/json";
            else if(rawPath.endsWith(".css")) mime="text/css";
            else if(rawPath.endsWith(".png")) mime="image/png";
            WebResourceResponse result=new WebResourceResponse(mime,"UTF-8",input);
            result.setResponseHeaders(new HashMap<String,String>() {{put("Access-Control-Allow-Origin", APP_ORIGIN);put("Cache-Control","no-cache");}});
            return result;
        } catch(IOException ignored) { return missing(); }
    }
    private WebResourceResponse missing() {
        return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",new HashMap<>(),new ByteArrayInputStream(new byte[0]));
    }

    public class AtlasNativeBridge {
        @JavascriptInterface public void openExternalUrl(String rawUrl) {
            if (rawUrl == null || rawUrl.isEmpty()) return;
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(rawUrl));
                startActivity(intent);
            } catch (Exception ignored) { }
        }

        @JavascriptInterface public String getAppVersionName() {
            return BuildConfig.VERSION_NAME;
        }

        @JavascriptInterface public int getAppVersionCode() {
            return BuildConfig.VERSION_CODE;
        }

        @JavascriptInterface public void saveBase64File(String filename, String data, String mime) {
            if (data==null || data.length()>48*1024*1024) return;
            final byte[] bytes;
            try { bytes=Base64.decode(data, Base64.DEFAULT); } catch(IllegalArgumentException ex) { return; }
            if(bytes.length>32*1024*1024)return;
            String safe=(filename==null?"atlas-backup.json":filename).replaceAll("[^A-Za-z0-9._-]","_");
            if(safe.isEmpty()) safe="atlas-backup.json";
            final String chosenName=safe;
            final String fileMime = "application/json"; // Somente backups JSON nesta versão.
            runOnUiThread(()->{
                if (pendingExport!=null) {Toast.makeText(MainActivity.this,"Conclua a exportação anterior.",Toast.LENGTH_SHORT).show();return;}
                pendingExport=bytes;
                pendingExportMime=fileMime;
                Intent pick=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                pick.setType(fileMime);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.putExtra(Intent.EXTRA_TITLE,chosenName);
                try {startActivityForResult(pick,PICK_EXPORT);}
                catch(ActivityNotFoundException ex){pendingExport=null;Toast.makeText(MainActivity.this,"Não foi possível abrir o seletor de arquivos.",Toast.LENGTH_LONG).show();}
            });
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_IMPORT) {
            if(pendingUpload!=null) {
                Uri[] result=(resultCode==RESULT_OK)?WebChromeClient.FileChooserParams.parseResult(resultCode,data):null;
                pendingUpload.onReceiveValue(result);
                pendingUpload=null;
            }
        } else if(requestCode==PICK_EXPORT) {
            byte[] bytes=pendingExport;
            pendingExport=null;
            if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&bytes!=null) {
                try(OutputStream out=getContentResolver().openOutputStream(data.getData())) {
                    if(out==null) throw new IOException("Arquivo indisponível");
                    out.write(bytes);
                    Toast.makeText(this,"Arquivo exportado com sucesso!",Toast.LENGTH_LONG).show();
                }catch(IOException err) {
                    Toast.makeText(this,"Erro ao exportar: "+err.getMessage(),Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    @Override public void onBackPressed() {
        if(web.canGoBack()) {web.goBack();return;}
        new AlertDialog.Builder(this)
            .setTitle("Sair do Atlas?")
            .setMessage("Suas alterações são salvas localmente. Faça backups regulares das fichas.")
            .setNegativeButton("Continuar jogando",(d,w)->d.dismiss())
            .setPositiveButton("Sair",(d,w)->finish())
            .show();
    }

    @Override protected void onDestroy() {
        if(web!=null){web.destroy();web=null;}
        super.onDestroy();
    }
}
