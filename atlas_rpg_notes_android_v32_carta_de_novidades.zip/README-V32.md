# Atlas RPG Notes — v0.32.0 Beta

## Novidades
- Carta de versão com **versão anterior registrada → versão atual**.
- Histórico acumulado com notas por versão, desde v29, para quem pulou atualizações.
- A v31 fornece a chave de versão instalada; atualizar v31→v32 exibirá precisamente as duas versões.
- Para instalações anteriores à v31 sem versão registrada, a carta mostra **Versão anterior não identificada**; evita inventar a versão.
- Novo visual de grimório arcano, com moldura e retrato circular do personagem opcional se existir.
- O botão **📜 Ver novidades** permite reler a carta e consultar o histórico completo.

## Segurança e dados
- Nenhum personagem é modificado pela carta; não se apagam fichas, imagens ou IDs.
- O avatar circular da v31 permanece intacto.
- O histórico de notas fica em `app/src/main/assets/www/release-notes.json`, editável a cada versão.
- Preserve a mesma chave de assinatura, ID Android e atualize para `versionCode 32`.
- Instalar por cima da v31, sem desinstalar, para preservar os dados.

## Limites
- A v32 registra versões para atualizações futuras; não consegue inferir com exatidão versões instaladas antes da introdução dessa chave.
- O projeto precisa ser compilado no GitHub Actions e testado no Android.
