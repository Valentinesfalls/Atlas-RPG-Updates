# Atlas RPG Notes v28 — passo a passo pelo celular

Este guia usa o repositório privado já criado: `Valentinesfalls/Atlas-RPG-Notes`.

## Preparação

Você precisa de **dois arquivos**, disponibilizados nesta conversa:

1. `atlas_rpg_notes_android_v28.zip` — projeto Android, pronto para extrair na nuvem.
2. `GERAR_ATLAS_RPG_NOTES_V28.yml` — fluxo de compilação do GitHub Actions.

**Não use** o ZIP v28 mais antigo: ele continha uma chave de assinatura de demonstração. A versão deste guia gera uma chave exclusiva do seu projeto.

## 1. Enviar o ZIP no repositório privado

1. Abra `https://github.com/Valentinesfalls/Atlas-RPG-Notes` pelo Chrome do celular.
2. Acesse **Código → Add file → Upload files**.
3. Envie `atlas_rpg_notes_android_v28.zip`.
4. Toque em **Commit changes**. O ZIP da v27 pode continuar no repositório.

## 2. Atualizar o workflow

1. Na aba **Código**, abra `.github/workflows/gerar-apk.yml`.
2. Toque em **Edit / ícone de lápis** (no Chrome, pode ser necessário **Site para computador**).
3. Apague o conteúdo antigo, cole TODO o conteúdo do arquivo `GERAR_ATLAS_RPG_NOTES_V28.yml` e pressione **Commit changes**.
4. Confira se o arquivo permanece em `.github/workflows/gerar-apk.yml`.

## 3. Criar segredo para proteger a assinatura

1. No mesmo repositório, abra **Settings → Secrets and variables → Actions**.
2. Toque em **New repository secret**.
3. Em **Name**, digite `ATLAS_SIGNING_PASSWORD`.
4. Em **Secret**, escolha uma senha forte com pelo menos **12 caracteres**.
5. Toque em **Add secret**. Guarde essa senha em um gerenciador de senhas; nunca a envie no chat.

Na primeira compilação, o GitHub cria uma assinatura única, protegida por essa senha, e guarda a chave criptografada em `signing/atlas-release.jks` dentro do repositório privado. Nas próximas compilações reutiliza a mesma chave. **Não exclua a chave nem altere a senha.** Mantenha uma cópia segura da chave e sua senha fora do GitHub.

## 4. Gerar a v28

1. Abra **Actions / Ações**.
2. Abra **Gerar APK do Atlas no GitHub**.
3. Toque em **Run workflow** e selecione `main`.
4. Quando estiver verde, abra a execução e role até **Artifacts**.
5. Baixe `Atlas-v28-APK-e-Atualizacao` e extraia o ZIP baixado.

Dentro estarão:
- `Atlas-RPG-Notes.apk`
- `update-manifest.json`

A primeira compilação também fará um commit automático da chave de assinatura no repositório privado. Isto é esperado.

## 5. Migrar do v27 sem perder a ficha

A v27 era assinada como **debug**; a v28 usa a nova assinatura. O Android pode bloquear a instalação por cima da v27.

1. Abra a v27 e faça um **Backup do Atlas**. Salve o JSON em local seguro.
2. Tente instalar o APK v28. Se aparecer conflito, desinstale **somente após confirmar que o backup foi salvo**.
3. Instale a v28.
4. Abra **Ficha → ⚙️ Ferramentas → Restaurar backup**.
5. Selecione seu backup JSON e confirme.

Depois, APKs v28+ assinados com a mesma chave e código de versão crescente poderão atualizar por cima sem apagar os dados locais em condições normais. Faça backup antes de qualquer atualização importante.

## 6. Criar o canal público de atualizações (separado do código privado)

1. Crie um novo repositório **público** chamado `Atlas-RPG-Updates` no GitHub.
2. Entre nele pelo Chrome e escolha **Add file → Upload files**.
3. Envie os dois arquivos extraídos do artefato: `Atlas-RPG-Notes.apk` e `update-manifest.json`.
4. Faça **Commit changes** na branch `main`.
5. Confira se estes links abrem:
   - `https://raw.githubusercontent.com/Valentinesfalls/Atlas-RPG-Updates/main/update-manifest.json`
   - `https://raw.githubusercontent.com/Valentinesfalls/Atlas-RPG-Updates/main/Atlas-RPG-Notes.apk`

**É só esse repositório de downloads que precisa ser público.** O `Atlas-RPG-Notes` continua privado, com o código e a chave de assinatura.

## 7. Como o jogador recebe atualizações

- O Atlas verifica o `update-manifest.json` público quando abre e quando o jogador toca em **Verificar atualização** no menu superior.
- Se houver um `versionCode` maior que o do APK instalado, aparece o aviso de nova versão.
- O botão abre o download do APK; o Android solicita ao jogador que confirme a instalação.
- **A instalação não é silenciosa**: é preciso baixar e confirmar. É necessária internet para verificar e baixar.
- Para v29, v30 e seguintes, o projeto deve aumentar o `versionCode` e atualizar `ATLAS_VERSION` e `update-manifest.json`, sempre reutilizando a MESMA chave; publique novamente os dois arquivos no repositório de downloads.

## Observações

- Esta conversa preparou os arquivos e validou sintaxe/estrutura, mas a nova compilação real ainda precisa rodar no GitHub.
- O workflow de teste v27 continua disponível no histórico e não deve ser usado para gerar atualizações do APK v28.
- Quem tem a v27 deve fazer a migração de assinatura uma vez. Para os jogadores novos, distribua diretamente a v28 assinada, não a v27 debug.


## Identidade visual aprovada
- Ícone escolhido: Grimório Arcano (livro de couro escuro, ornamentos dourados, estrela e runas azuis).
- Ícone Android: `app/src/main/res/drawable-nodpi/atlas_icon.png`.
- Ícones PWA: `app/src/main/assets/www/icons/icon-192.png` e `icon-512.png`.
- Nome exibido: **Atlas RPG Notes**.
- Nome do APK: **Atlas-RPG-Notes.apk**.
